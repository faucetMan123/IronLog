# Iron Log — GitHub Pages Deployment

This folder is ready for GitHub Pages.

Required repo structure:

```text
index.html
sw.js
.nojekyll
README.md
```

GitHub settings:

1. Go to Settings → Pages.
2. Build and deployment → Source: Deploy from a branch.
3. Branch: main.
4. Folder: /root.
5. Save.

Do not upload `index(3).html`. The entry file must be named exactly `index.html`.
